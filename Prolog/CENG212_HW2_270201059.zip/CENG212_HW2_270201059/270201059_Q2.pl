?- is_faculty_member('Damla Oguz'). % true
?- are_in_common_course('Damla Oguz','Huseyin Unlu'). % true (ceng212)
?- is_assistant_of('Leyla Tekin','CENG214'). %true
?- are_given_by_same_instructor('CENG222','CENG113'). %true (nesli erdogmus)
?- has_enough_staff_to_instruct('CENG212'). % (true)
?- is_in_administiration('Nesli Erdogmus'). % true
?- is_faculty_member('Leyla Tekin'). %false
?- are_in_common_course('Damla Oguz','Ersin Cine'). %false
